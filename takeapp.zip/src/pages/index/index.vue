<template>
    <div>
        <indextop></indextop>
        <indexcenter></indexcenter>
    </div>
</template>

<script>
import indextop from "./index_top"
import indexcenter from "./index_center"
    export default {
        components:{
            indextop,
            indexcenter,
        }
    }
</script>

<style scoped>

</style>